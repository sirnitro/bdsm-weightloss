</main>
<footer class="site-footer">
    <div class="container">
        <p>&copy; <?= date('Y') ?> BDSM Weight Loss. All rights reserved.</p>
    </div>
</footer>
<script src="<?= BASE_URL ?>js/main.js"></script>
</body>
</html>

