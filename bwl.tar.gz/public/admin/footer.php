    </main>
    <footer class="admin-footer">
        &copy; <?= date('Y') ?> BDSM Weight Loss Admin Panel
    </footer>
</body>
</html>

