<?php require_once 'config.php'; ?>
<?php require_once 'header.php'; ?>

<h2>Welcome, Admin</h2>
<p>Use the menu to manage users, view logs, and maintain the system.</p>

<?php require_once 'footer.php'; ?>

