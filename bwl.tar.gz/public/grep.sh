grep -Ri --color=auto "\bdomme\b" * > ../refactor-todo.txt
grep -Ri --color=auto "\bsubmissive\b" * >> ../refactor-todo.txt
grep -Ri --color=auto "\bher\b" * >> ../refactor-todo.txt
grep -Ri --color=auto "\bhim\b" * >> ../refactor-todo.txt
grep -Ri --color=auto "Domme" * >> ../refactor-todo.txt

